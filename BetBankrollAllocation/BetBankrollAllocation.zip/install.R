install.packages('shiny')
install.packages('quadprog')
install.packages('plotly')